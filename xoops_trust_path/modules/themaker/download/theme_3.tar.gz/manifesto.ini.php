<?php
/**

[Manifesto]
Name="nouphet_test"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=""
ScreenShot="thumnbail.png"
Description="xhtml, 1カラム / 3カラム,テスト用
薄いブルーのテーマ"
W3C=NG

Licence="Creative Commons"

*/
?>