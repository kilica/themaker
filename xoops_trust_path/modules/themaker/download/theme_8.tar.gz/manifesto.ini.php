<?php
/**

[Manifesto]
Name="bootstrap"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=""
ScreenShot="thumnbail.png"
Description="html5, 2カラム（右） / 2カラム（右）,Bootstrap, from Twitter を使ったテストテーマです。"
W3C=NG

Licence="Creative Commons"

*/
?>