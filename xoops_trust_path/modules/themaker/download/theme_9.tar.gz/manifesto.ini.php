<?php
/**

[Manifesto]
Name="machicon"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author="mitsunobu"
ScreenShot="thumnbail.png"
Description="html5, 2カラム（右） / 2カラム（右）,Theme For Machicon"
W3C=NG

Licence="Creative Commons"

*/
?>