<?php
/**

[Manifesto]
Name="potal"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=""
ScreenShot="thumnbail.png"
Description="html5, 3カラム / 2カラム（左）,社内ポータル"
W3C=NG

Licence="Creative Commons"

*/
?>