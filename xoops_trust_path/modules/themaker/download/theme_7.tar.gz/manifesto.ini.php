<?php
/**

[Manifesto]
Name="test"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=""
ScreenShot="thumnbail.png"
Description="xhtml, 3カラム / 3カラム,test"
W3C=NG

Licence="Creative Commons"

*/
?>