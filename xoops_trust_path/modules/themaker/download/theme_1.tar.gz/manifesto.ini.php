<?php
/**

[Manifesto]
Name="kilica1"
Depends=Legacy_RenderSystem,legacy
Url=""
Version="1.00"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=""
ScreenShot="thumnbail.png"
Description="xhtml, 2カラム（左） / 2カラム（左）,sample"
W3C=NG

Licence="Creative Commons"

*/
?>